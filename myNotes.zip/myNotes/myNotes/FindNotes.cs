﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace myNotes
{
	public partial class FindNotes : Form
	{
		public FindNotes()
		{
			InitializeComponent();
		}

		private void btnStart_Click(object sender, EventArgs e)
		{
			if (radioButton1.Checked) Tag = 1;
			else Tag = 2;
			Close();
		}

		private void txbname_TextChanged(object sender, EventArgs e)
		{

		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
			if (chkDate.Checked)
			{
				numDate.Enabled = true;
				numMonth.Enabled = true;
				numYear.Enabled = true;
			}
			else
			{
				numDate.Enabled = false;
				numMonth.Enabled = false;
				numYear.Enabled = false;
			}
		}

		private void radioButton1_CheckedChanged(object sender, EventArgs e)
		{
			if (radioButton1.Checked)
			{
				txbname.Enabled = false;
				txbText.Enabled = true;
				txbText.SelectAll();
				txbText.Focus();
			}
			else
			{
				txbname.Enabled = true;
				txbText.Enabled = false;
				txbname.SelectAll();
				txbname.Focus();
			}
		}
		
	}
}
