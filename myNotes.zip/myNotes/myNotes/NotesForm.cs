﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace myNotes
{
	[Serializable]
	public partial class NotesForm : Form
	{
		bool moving = false;
		int x, y;
		Notes tmp_not;
		public NotesForm(Notes note)
		{
			InitializeComponent();
			tmp_not = note;
		}
		public NotesForm()
		{
			InitializeComponent();

		}
		private void NotesForm_Load(object sender, EventArgs e)
		{
			try
			{
				toolStripStatusLabel1.Text = "Время создания: " + tmp_not.DateTime;
				textBox1.Text = tmp_not.Text;
				txbName.Text = tmp_not.Name_notes;
			}
			catch (Exception s)
			{
				MessageBox.Show(s.Message + s.StackTrace);
			}
		}

	

		private void CloseStrip_Click(object sender, EventArgs e)
		{
			
			Close();
		}

		private void ChangeBackColor_Click(object sender, EventArgs e)
		{
			ColorDialog colorDialog = new ColorDialog();
			if (colorDialog.ShowDialog() == DialogResult.OK)
			{
				textBox1.BackColor = colorDialog.Color;

			}
		}

		private void NotesForm_MouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				x = Cursor.Position.X;
				y = Cursor.Position.Y;
				moving = true;
			}

		}

		private void NotesForm_MouseMove(object sender, MouseEventArgs e)
		{
			try
			{
				if (moving)
				{
					this.Left = this.Left + (Cursor.Position.X - x);
					this.Top = this.Top + (Cursor.Position.Y - y);
					x = Cursor.Position.X;
					y = Cursor.Position.Y;
				}
			}
			catch (Exception s)
			{
				MessageBox.Show(s.Message + s.StackTrace);
			}
		}

		private void NotesForm_MouseUp(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				if (moving) moving = false;
			}
		}


		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				tmp_not.Text = textBox1.Text;
				tmp_not.DateTime = DateTime.Now;
				tmp_not.Name_notes = txbName.Text;
				this.Close();
			}
			catch (Exception s)
			{
				MessageBox.Show(s.Message + s.StackTrace);
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			textBox1.SelectAll();
			textBox1.Cut();
			txbName.SelectAll();
			txbName.Cut();
		}

		private void отменитьИзмененияToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (textBox1.CanUndo)
			{
				textBox1.Undo();
			}
			if (txbName.CanUndo) txbName.Undo();
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{
			
			tmp_not.Text = textBox1.Text;
			if (textBox1.Modified || txbName.Modified) отменитьИзмененияToolStripMenuItem.Enabled = true;
			else отменитьИзмененияToolStripMenuItem.Enabled = false;
			
		}



		private void toolStripMenuItem2_Click(object sender, EventArgs e)
		{
			ColorDialog colorDialog = new ColorDialog();
			if (colorDialog.ShowDialog() == DialogResult.OK)
			{
				txbName.BackColor = colorDialog.Color;
			}
		}

		private void toolStripMenuItem1_Click(object sender, EventArgs e)
		{
			try
			{
				FontDialog fontDialog = new FontDialog();
				fontDialog.ShowColor = true;
				fontDialog.ShowEffects = true;
				if (fontDialog.ShowDialog() == DialogResult.OK)
				{
					txbName.Font = fontDialog.Font;
					txbName.ForeColor = fontDialog.Color;
				}
			}
			catch (Exception s)
			{
				MessageBox.Show(s.Message + s.StackTrace);
			}
		}

		private void txbName_TextChanged(object sender, EventArgs e)
		{
			tmp_not.Name_notes = txbName.Text;
		}

		private void изменитьШрифтToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				FontDialog fontDialog = new FontDialog();
				fontDialog.ShowColor = true;
				fontDialog.ShowEffects = true;
				if (fontDialog.ShowDialog() == DialogResult.OK)
				{
					textBox1.Font = fontDialog.Font;
					textBox1.ForeColor = fontDialog.Color;
				}
			}
			catch (Exception s)
			{
				MessageBox.Show(s.Message + s.StackTrace);
			}
		}
	}
}
