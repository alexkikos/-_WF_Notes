﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;


namespace myNotes
{
	[Serializable]
	public class Notes
	{
		string text;
		string name_notes;
		DateTime dateTime;
		
		
		[NonSerialized]
		bool visible;
		public string Text { get => text; set => text = value; }
		public DateTime DateTime { get => dateTime; set => dateTime = value; }
		public bool Visible { get => visible; set => visible = value; }
		public string Name_notes { get => name_notes; set => name_notes = value; }

		public override string ToString()
		{
			return "Name: " + name_notes + " | Time: " + dateTime.ToString();
		}

		public override bool Equals(object obj)
		{
			return obj is Notes notes &&
				   text == notes.text &&
				   name_notes == notes.name_notes &&
				   dateTime == notes.dateTime;				   
		}

		public override int GetHashCode()
		{
			var hashCode = 830610071;
			hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(text);
			hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(name_notes);
			hashCode = hashCode * -1521134295 + dateTime.GetHashCode();
			hashCode = hashCode * -1521134295 + visible.GetHashCode();
			return hashCode;
		}

		public Notes()
		{
			this.text = "";
			this.dateTime = DateTime.Now;
			visible = false;
			name_notes = "";
		}
	}
}
