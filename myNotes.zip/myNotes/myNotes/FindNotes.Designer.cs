﻿namespace myNotes
{
	partial class FindNotes
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.btnStart = new System.Windows.Forms.Button();
			this.txbText = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.radioButton2 = new System.Windows.Forms.RadioButton();
			this.radioButton1 = new System.Windows.Forms.RadioButton();
			this.label2 = new System.Windows.Forms.Label();
			this.txbname = new System.Windows.Forms.TextBox();
			this.chkDate = new System.Windows.Forms.CheckBox();
			this.numDate = new System.Windows.Forms.NumericUpDown();
			this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.numMonth = new System.Windows.Forms.NumericUpDown();
			this.numYear = new System.Windows.Forms.NumericUpDown();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numDate)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numMonth)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numYear)).BeginInit();
			this.SuspendLayout();
			// 
			// btnStart
			// 
			this.btnStart.BackgroundImage = global::myNotes.Properties.Resources._1;
			this.btnStart.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnStart.Font = new System.Drawing.Font("Minion Pro Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.btnStart.Location = new System.Drawing.Point(113, 178);
			this.btnStart.Name = "btnStart";
			this.btnStart.Size = new System.Drawing.Size(80, 36);
			this.btnStart.TabIndex = 1;
			this.btnStart.Text = "Найти";
			this.btnStart.UseVisualStyleBackColor = true;
			this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
			// 
			// txbText
			// 
			this.txbText.Font = new System.Drawing.Font("Minion Pro Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.txbText.Location = new System.Drawing.Point(97, 30);
			this.txbText.Name = "txbText";
			this.txbText.Size = new System.Drawing.Size(167, 32);
			this.txbText.TabIndex = 4;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Minion Pro Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label1.Location = new System.Drawing.Point(45, 33);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(50, 24);
			this.label1.TabIndex = 2;
			this.label1.Text = "Текст";
			// 
			// groupBox1
			// 
			this.groupBox1.BackColor = System.Drawing.Color.Transparent;
			this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.groupBox1.CausesValidation = false;
			this.groupBox1.Controls.Add(this.radioButton2);
			this.groupBox1.Controls.Add(this.radioButton1);
			this.groupBox1.ForeColor = System.Drawing.Color.White;
			this.groupBox1.ImeMode = System.Windows.Forms.ImeMode.Off;
			this.groupBox1.Location = new System.Drawing.Point(12, 12);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(27, 98);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			// 
			// radioButton2
			// 
			this.radioButton2.AutoSize = true;
			this.radioButton2.Font = new System.Drawing.Font("Minion Pro Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.radioButton2.Location = new System.Drawing.Point(7, 70);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.Size = new System.Drawing.Size(14, 13);
			this.radioButton2.TabIndex = 2;
			this.radioButton2.Tag = "2";
			this.radioButton2.UseVisualStyleBackColor = true;
			this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// radioButton1
			// 
			this.radioButton1.AutoSize = true;
			this.radioButton1.Checked = true;
			this.radioButton1.Font = new System.Drawing.Font("Minion Pro Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.radioButton1.Location = new System.Drawing.Point(6, 28);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.Size = new System.Drawing.Size(14, 13);
			this.radioButton1.TabIndex = 0;
			this.radioButton1.TabStop = true;
			this.radioButton1.Tag = "1";
			this.radioButton1.UseVisualStyleBackColor = true;
			this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Minion Pro Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label2.Location = new System.Drawing.Point(46, 77);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(43, 24);
			this.label2.TabIndex = 5;
			this.label2.Text = "Имя";
			// 
			// txbname
			// 
			this.txbname.Enabled = false;
			this.txbname.Font = new System.Drawing.Font("Minion Pro Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.txbname.Location = new System.Drawing.Point(97, 74);
			this.txbname.Name = "txbname";
			this.txbname.Size = new System.Drawing.Size(167, 32);
			this.txbname.TabIndex = 5;
			this.txbname.TextChanged += new System.EventHandler(this.txbname_TextChanged);
			// 
			// chkDate
			// 
			this.chkDate.AutoSize = true;
			this.chkDate.BackColor = System.Drawing.Color.Transparent;
			this.chkDate.Font = new System.Drawing.Font("Minion Pro Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.chkDate.Location = new System.Drawing.Point(20, 125);
			this.chkDate.Name = "chkDate";
			this.chkDate.Size = new System.Drawing.Size(64, 28);
			this.chkDate.TabIndex = 3;
			this.chkDate.Text = "Дата";
			this.chkDate.UseVisualStyleBackColor = false;
			this.chkDate.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
			// 
			// numDate
			// 
			this.numDate.Enabled = false;
			this.numDate.Font = new System.Drawing.Font("Minion Pro Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.numDate.Location = new System.Drawing.Point(97, 122);
			this.numDate.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
			this.numDate.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.numDate.Name = "numDate";
			this.numDate.Size = new System.Drawing.Size(44, 32);
			this.numDate.TabIndex = 6;
			this.toolTip1.SetToolTip(this.numDate, "День");
			this.numDate.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			// 
			// numMonth
			// 
			this.numMonth.Enabled = false;
			this.numMonth.Font = new System.Drawing.Font("Minion Pro Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.numMonth.Location = new System.Drawing.Point(149, 122);
			this.numMonth.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
			this.numMonth.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.numMonth.Name = "numMonth";
			this.numMonth.Size = new System.Drawing.Size(44, 32);
			this.numMonth.TabIndex = 7;
			this.toolTip1.SetToolTip(this.numMonth, "Месяц");
			this.numMonth.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			// 
			// numYear
			// 
			this.numYear.Enabled = false;
			this.numYear.Font = new System.Drawing.Font("Minion Pro Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.numYear.Location = new System.Drawing.Point(204, 122);
			this.numYear.Maximum = new decimal(new int[] {
            2030,
            0,
            0,
            0});
			this.numYear.Minimum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
			this.numYear.Name = "numYear";
			this.numYear.Size = new System.Drawing.Size(60, 32);
			this.numYear.TabIndex = 8;
			this.toolTip1.SetToolTip(this.numYear, "Год");
			this.numYear.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
			// 
			// FindNotes
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = global::myNotes.Properties.Resources._1;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.ClientSize = new System.Drawing.Size(284, 226);
			this.Controls.Add(this.numYear);
			this.Controls.Add(this.numMonth);
			this.Controls.Add(this.numDate);
			this.Controls.Add(this.chkDate);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txbname);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txbText);
			this.Controls.Add(this.btnStart);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "FindNotes";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "FindNotes";
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numDate)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numMonth)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numYear)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnStart;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ToolTip toolTip1;
		public System.Windows.Forms.GroupBox groupBox1;
		public System.Windows.Forms.TextBox txbText;
		public System.Windows.Forms.RadioButton radioButton2;
		public System.Windows.Forms.RadioButton radioButton1;
		public System.Windows.Forms.TextBox txbname;
		public System.Windows.Forms.CheckBox chkDate;
		public System.Windows.Forms.NumericUpDown numDate;
		public System.Windows.Forms.NumericUpDown numMonth;
		public System.Windows.Forms.NumericUpDown numYear;
	}
}