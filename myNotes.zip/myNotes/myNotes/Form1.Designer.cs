﻿namespace myNotes
{
	partial class Form1
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
			this.lstBoxAllNotes = new System.Windows.Forms.ListBox();
			this.cntxMainWindow = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.cntxMainDelete = new System.Windows.Forms.ToolStripMenuItem();
			this.cntxMainFon = new System.Windows.Forms.ToolStripMenuItem();
			this.cntxMainFont = new System.Windows.Forms.ToolStripMenuItem();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.findToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.refreshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
			this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.CreateNote = new System.Windows.Forms.ToolStripMenuItem();
			this.развернутьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.cntMainExit = new System.Windows.Forms.ToolStripMenuItem();
			this.SticksOnFirstPosition = new System.Windows.Forms.ToolStripMenuItem();
			this.StickOnFirsScreen = new System.Windows.Forms.ToolStripMenuItem();
			this.CloseActiveStick = new System.Windows.Forms.ToolStripMenuItem();
			this.CloseAllOpenSticks = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripContainer1.ContentPanel.SuspendLayout();
			this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
			this.toolStripContainer1.SuspendLayout();
			this.cntxMainWindow.SuspendLayout();
			this.menuStrip1.SuspendLayout();
			this.contextMenuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// toolStripContainer1
			// 
			// 
			// toolStripContainer1.ContentPanel
			// 
			this.toolStripContainer1.ContentPanel.Controls.Add(this.lstBoxAllNotes);
			this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(364, 221);
			this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
			this.toolStripContainer1.Name = "toolStripContainer1";
			this.toolStripContainer1.Size = new System.Drawing.Size(364, 245);
			this.toolStripContainer1.TabIndex = 0;
			this.toolStripContainer1.Text = "toolStripContainer1";
			// 
			// toolStripContainer1.TopToolStripPanel
			// 
			this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.menuStrip1);
			// 
			// lstBoxAllNotes
			// 
			this.lstBoxAllNotes.ContextMenuStrip = this.cntxMainWindow;
			this.lstBoxAllNotes.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lstBoxAllNotes.Font = new System.Drawing.Font("Minion Pro Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.lstBoxAllNotes.ForeColor = System.Drawing.Color.Black;
			this.lstBoxAllNotes.FormattingEnabled = true;
			this.lstBoxAllNotes.HorizontalScrollbar = true;
			this.lstBoxAllNotes.ItemHeight = 24;
			this.lstBoxAllNotes.Location = new System.Drawing.Point(0, 0);
			this.lstBoxAllNotes.Name = "lstBoxAllNotes";
			this.lstBoxAllNotes.ScrollAlwaysVisible = true;
			this.lstBoxAllNotes.Size = new System.Drawing.Size(364, 221);
			this.lstBoxAllNotes.TabIndex = 0;
			this.lstBoxAllNotes.DoubleClick += new System.EventHandler(this.lstBoxAllNotes_DoubleClick);
			// 
			// cntxMainWindow
			// 
			this.cntxMainWindow.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cntxMainDelete,
            this.CloseActiveStick,
            this.CloseAllOpenSticks,
            this.cntxMainFon,
            this.cntxMainFont,
            this.SticksOnFirstPosition,
            this.cntMainExit});
			this.cntxMainWindow.Name = "cntxMainWindow";
			this.cntxMainWindow.Size = new System.Drawing.Size(233, 158);
			this.cntxMainWindow.Opening += new System.ComponentModel.CancelEventHandler(this.cntxMainWindow_Opening);
			// 
			// cntxMainDelete
			// 
			this.cntxMainDelete.Name = "cntxMainDelete";
			this.cntxMainDelete.Size = new System.Drawing.Size(232, 22);
			this.cntxMainDelete.Text = "Удалить";
			// 
			// cntxMainFon
			// 
			this.cntxMainFon.Name = "cntxMainFon";
			this.cntxMainFon.Size = new System.Drawing.Size(232, 22);
			this.cntxMainFon.Text = "Фон";
			// 
			// cntxMainFont
			// 
			this.cntxMainFont.Name = "cntxMainFont";
			this.cntxMainFont.Size = new System.Drawing.Size(232, 22);
			this.cntxMainFont.Text = "Шрифт";
			// 
			// menuStrip1
			// 
			this.menuStrip1.BackgroundImage = global::myNotes.Properties.Resources._11;
			this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem,
            this.deleteToolStripMenuItem,
            this.findToolStripMenuItem,
            this.refreshToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.loadToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(364, 24);
			this.menuStrip1.TabIndex = 0;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// addToolStripMenuItem
			// 
			this.addToolStripMenuItem.Name = "addToolStripMenuItem";
			this.addToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
			this.addToolStripMenuItem.Text = "Add";
			this.addToolStripMenuItem.Click += new System.EventHandler(this.addToolStripMenuItem_Click);
			// 
			// deleteToolStripMenuItem
			// 
			this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
			this.deleteToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
			this.deleteToolStripMenuItem.Text = "Delete";
			this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
			// 
			// findToolStripMenuItem
			// 
			this.findToolStripMenuItem.Name = "findToolStripMenuItem";
			this.findToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
			this.findToolStripMenuItem.Text = "Find";
			this.findToolStripMenuItem.Click += new System.EventHandler(this.findToolStripMenuItem_Click);
			// 
			// refreshToolStripMenuItem
			// 
			this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
			this.refreshToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
			this.refreshToolStripMenuItem.Text = "Refresh";
			this.refreshToolStripMenuItem.Click += new System.EventHandler(this.refreshToolStripMenuItem_Click);
			// 
			// saveToolStripMenuItem
			// 
			this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
			this.saveToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
			this.saveToolStripMenuItem.Text = "Save";
			this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
			// 
			// loadToolStripMenuItem
			// 
			this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
			this.loadToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
			this.loadToolStripMenuItem.Text = "Load";
			this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
			// 
			// notifyIcon1
			// 
			this.notifyIcon1.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
			this.notifyIcon1.BalloonTipText = "Заметки теперь тут!";
			this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;
			this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
			this.notifyIcon1.Text = "Заметки";
			this.notifyIcon1.Visible = true;
			this.notifyIcon1.DoubleClick += new System.EventHandler(this.notifyIcon1_DoubleClick);
			// 
			// contextMenuStrip1
			// 
			this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CreateNote,
            this.развернутьToolStripMenuItem,
            this.StickOnFirsScreen,
            this.выходToolStripMenuItem});
			this.contextMenuStrip1.Name = "contextMenuStrip1";
			this.contextMenuStrip1.Size = new System.Drawing.Size(225, 92);
			// 
			// CreateNote
			// 
			this.CreateNote.Name = "CreateNote";
			this.CreateNote.Size = new System.Drawing.Size(224, 22);
			this.CreateNote.Text = "Создать заметку";
			this.CreateNote.Click += new System.EventHandler(this.CreateNote_Click);
			// 
			// развернутьToolStripMenuItem
			// 
			this.развернутьToolStripMenuItem.Enabled = false;
			this.развернутьToolStripMenuItem.Name = "развернутьToolStripMenuItem";
			this.развернутьToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
			this.развернутьToolStripMenuItem.Text = "Развернуть";
			this.развернутьToolStripMenuItem.Click += new System.EventHandler(this.развернутьToolStripMenuItem_Click);
			// 
			// выходToolStripMenuItem
			// 
			this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
			this.выходToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
			this.выходToolStripMenuItem.Text = "Выход";
			this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
			// 
			// cntMainExit
			// 
			this.cntMainExit.Name = "cntMainExit";
			this.cntMainExit.Size = new System.Drawing.Size(232, 22);
			this.cntMainExit.Text = "Выйти";
			// 
			// SticksOnFirstPosition
			// 
			this.SticksOnFirstPosition.Name = "SticksOnFirstPosition";
			this.SticksOnFirstPosition.Size = new System.Drawing.Size(232, 22);
			this.SticksOnFirstPosition.Text = "Стикеры на переднем плане";
			// 
			// StickOnFirsScreen
			// 
			this.StickOnFirsScreen.Enabled = false;
			this.StickOnFirsScreen.Name = "StickOnFirsScreen";
			this.StickOnFirsScreen.Size = new System.Drawing.Size(224, 22);
			this.StickOnFirsScreen.Text = "Стикеры на передний план";
			// 
			// CloseActiveStick
			// 
			this.CloseActiveStick.Enabled = false;
			this.CloseActiveStick.Name = "CloseActiveStick";
			this.CloseActiveStick.Size = new System.Drawing.Size(232, 22);
			this.CloseActiveStick.Text = "Закрыть стик";
			this.CloseActiveStick.Click += new System.EventHandler(this.CloseActiveStick_Click);
			// 
			// CloseAllOpenSticks
			// 
			this.CloseAllOpenSticks.Enabled = false;
			this.CloseAllOpenSticks.Name = "CloseAllOpenSticks";
			this.CloseAllOpenSticks.Size = new System.Drawing.Size(232, 22);
			this.CloseAllOpenSticks.Text = "Закрыть все открытые стики";
			this.CloseAllOpenSticks.Click += new System.EventHandler(this.CloseAllOpenSticks_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(364, 245);
			this.Controls.Add(this.toolStripContainer1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MainMenuStrip = this.menuStrip1;
			this.MinimumSize = new System.Drawing.Size(285, 278);
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "MyNotes";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
			this.Load += new System.EventHandler(this.Form1_Load_1);
			this.SizeChanged += new System.EventHandler(this.Form1_SizeChanged);
			this.toolStripContainer1.ContentPanel.ResumeLayout(false);
			this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
			this.toolStripContainer1.TopToolStripPanel.PerformLayout();
			this.toolStripContainer1.ResumeLayout(false);
			this.toolStripContainer1.PerformLayout();
			this.cntxMainWindow.ResumeLayout(false);
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.contextMenuStrip1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.ToolStripContainer toolStripContainer1;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem findToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
		public System.Windows.Forms.ListBox lstBoxAllNotes;
		private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;
		private System.Windows.Forms.NotifyIcon notifyIcon1;
		private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
		private System.Windows.Forms.ToolStripMenuItem CreateNote;
		private System.Windows.Forms.ToolStripMenuItem развернутьToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
		private System.Windows.Forms.ContextMenuStrip cntxMainWindow;
		private System.Windows.Forms.ToolStripMenuItem cntxMainDelete;
		private System.Windows.Forms.ToolStripMenuItem cntxMainFon;
		private System.Windows.Forms.ToolStripMenuItem cntxMainFont;
		private System.Windows.Forms.ToolStripMenuItem cntMainExit;
		private System.Windows.Forms.ToolStripMenuItem SticksOnFirstPosition;
		private System.Windows.Forms.ToolStripMenuItem StickOnFirsScreen;
		private System.Windows.Forms.ToolStripMenuItem CloseActiveStick;
		private System.Windows.Forms.ToolStripMenuItem CloseAllOpenSticks;
	}
}

