﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace myNotes
{
	public partial class Form1 : Form
	{

		bool searching = false;
		FindNotes findNotes;
		List<Notes> notes;//все наши нотатки
		List<NotesForm> open_windows;//открытые окна
		NotesForm create_notes_form;
		List<int> searh_request;//результаты поиска

		public Form1()
		{
			InitializeComponent();
			notes = new List<Notes>();
			open_windows = new List<NotesForm>();
			findNotes = new FindNotes();
			searh_request = new List<int>();
			cntxMainDelete.Click += CntxMainDelete_Click;
			cntMainExit.Click += (s, e) =>
			{
				Close();
			};
			cntxMainFont.Click += (s, e) =>
			{
				FontDialog fontDialog = new FontDialog();
				fontDialog.ShowColor = true;
				if (fontDialog.ShowDialog() == DialogResult.OK)
				{
					lstBoxAllNotes.Font = fontDialog.Font;
					lstBoxAllNotes.ForeColor = fontDialog.Color;
				}
			};
			cntxMainFon.Click += (s, e) =>
			{
				ColorDialog colorDialog = new ColorDialog();
				if (colorDialog.ShowDialog() == DialogResult.OK)
				{
					lstBoxAllNotes.BackColor = colorDialog.Color;
				}

			};
			SticksOnFirstPosition.Click += SticksOnFirstPosition_Click;
			cntxMainWindow.Opening += (t, m) =>
			{
				if (open_windows.Count > 0)
				{
					SticksOnFirstPosition.Enabled = true;
					StickOnFirsScreen.Enabled = true;
				}
				else
				{
					SticksOnFirstPosition.Enabled = false;
					StickOnFirsScreen.Enabled = false;
				}
			};
			StickOnFirsScreen.Click += (s, e) =>
			{
				if (StickOnFirsScreen.Checked)
				{
					StickOnFirsScreen.Checked = false;
					SticksOnFirstPosition_Click(null, null);
				}
				else
				{

					StickOnFirsScreen.Checked = true;
					SticksOnFirstPosition_Click(null, null);
				}
			};
		}

		private void SticksOnFirstPosition_Click(object sender, EventArgs e)
		{
			if (SticksOnFirstPosition.Checked)
			{
				SticksOnFirstPosition.Checked = false;
				StickOnFirsScreen.Checked = false;
				for (int i = 0; i < notes.Count; i++)
				{
					if (notes[i].Visible)
					{
						open_windows[i].TopMost = false;
					}
				}
			}
			else
			{
				SticksOnFirstPosition.Checked = true;
				StickOnFirsScreen.Checked = true;
				for (int i = 0; i < notes.Count; i++)
				{
					if (notes[i].Visible)
					{
						open_windows[i].TopMost = true;
					}
				}
			}
		}

		private void CntxMainDelete_Click(object sender, EventArgs e)
		{
			deleteToolStripMenuItem_Click(null, null);
		}

		private void addToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Notes note = new Notes();
			create_notes_form = new NotesForm(note);
			if (create_notes_form.ShowDialog() == DialogResult.OK)
			{
				lstBoxAllNotes.Items.Add(note.ToString());
				notes.Add(note);
				open_windows.Add(create_notes_form);
			}
		}

		private void Create_notes_form_FormClosing(object sender, FormClosingEventArgs e)
		{
			try
			{
				NotesForm tmp = sender as NotesForm;
				Notes tnotes = notes.Find(s => s.Text == tmp.textBox1.Text && s.Name_notes == tmp.txbName.Text);
				if (tnotes != null) tnotes.Visible = false;
				//обновляю листбокс на случай изменений
				if (lstBoxAllNotes.Items.Count > 0)
				{
					lstBoxAllNotes.Items.Clear();
					foreach (var item in notes)
					{
						lstBoxAllNotes.Items.Add(item);
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace);
			}
		}

		private void lstBoxAllNotes_DoubleClick(object sender, EventArgs e)
		{
			try
			{
				if (!searching)
				{
					if (notes.Count > 0)
					{
						if (lstBoxAllNotes.SelectedIndex != ListBox.NoMatches)
						{
							if (!notes[lstBoxAllNotes.SelectedIndex].Visible)
							{
								notes[lstBoxAllNotes.SelectedIndex].Visible = true;
								Notes nts = notes[lstBoxAllNotes.SelectedIndex];
								//создаю новую форму и закидываю туда наши нотатки
								NotesForm notesForm1 = new NotesForm(nts);
								//при закрытии подписываемся на евент
								notesForm1.FormClosing += Create_notes_form_FormClosing;
								notesForm1.Show();

								//загружаю настройки из ранее созданной формы
								notesForm1.textBox1.BackColor = open_windows[lstBoxAllNotes.SelectedIndex].textBox1.BackColor;
								notesForm1.textBox1.Font = open_windows[lstBoxAllNotes.SelectedIndex].textBox1.Font;
								notesForm1.textBox1.ForeColor = open_windows[lstBoxAllNotes.SelectedIndex].textBox1.ForeColor;
								notesForm1.txbName.BackColor = open_windows[lstBoxAllNotes.SelectedIndex].txbName.BackColor;
								notesForm1.txbName.Font = open_windows[lstBoxAllNotes.SelectedIndex].txbName.Font;
								notesForm1.txbName.ForeColor = open_windows[lstBoxAllNotes.SelectedIndex].txbName.ForeColor;
								if (SticksOnFirstPosition.Checked) notesForm1.TopMost = true;
								//заменяю старую форму на новую, на тот случай если мы в форме что то измеим
								open_windows[lstBoxAllNotes.SelectedIndex] = notesForm1;
							}
							else
							{
								//если заметки открыта, делаю фокус на нее
								NotesForm notesForm1 = open_windows[lstBoxAllNotes.SelectedIndex];
								notesForm1.Focus();
							}
						}
					}
				}
				else
				{
					if (lstBoxAllNotes.SelectedIndex != ListBox.NoMatches)
					{
						//поисковй режим
						Notes tmp = notes[searh_request[lstBoxAllNotes.SelectedIndex]];
						NotesForm t = new NotesForm(tmp);
						if (open_windows.Count > 0)
						{
							t.textBox1.BackColor = open_windows[searh_request[lstBoxAllNotes.SelectedIndex]].textBox1.BackColor;
							t.textBox1.Font = open_windows[searh_request[lstBoxAllNotes.SelectedIndex]].textBox1.Font;
							t.textBox1.ForeColor = open_windows[searh_request[lstBoxAllNotes.SelectedIndex]].textBox1.ForeColor;

							t.txbName.BackColor = open_windows[searh_request[lstBoxAllNotes.SelectedIndex]].txbName.BackColor;
							t.txbName.Font = open_windows[searh_request[lstBoxAllNotes.SelectedIndex]].txbName.Font;
							t.txbName.ForeColor = open_windows[searh_request[lstBoxAllNotes.SelectedIndex]].txbName.ForeColor;
						}
						open_windows[searh_request[lstBoxAllNotes.SelectedIndex]] = t;
						t.ShowDialog();

					}
				}


			}
			catch (Exception ex)
			{
				//да, я проверю, с поиском что то
				MessageBox.Show(ex.Message + ex.StackTrace, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

			}
		}



		private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (lstBoxAllNotes.SelectedIndex != ListBox.NoMatches)
				{
					int index = lstBoxAllNotes.SelectedIndex;
					Notes nt;
					if (!searching)
					{
						nt = notes[index];
					}
					else
					{
						nt = notes[searh_request[lstBoxAllNotes.SelectedIndex]];
					}
					if (nt != null)
					{
						NotesForm remov = open_windows.Find(s => s.textBox1.Text == nt.Text && s.txbName.Text == nt.Name_notes);
						if (remov != null)
						{
							open_windows.Remove(remov);
							remov.Close();
						}
						else open_windows.RemoveAt(index);
						lstBoxAllNotes.Items.RemoveAt(index);//?
						notes.Remove(nt);
					}
				}


			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace);
			}
		}


		private void saveToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (notes.Count > 0)
				{
					SaveFileDialog saveFileDialog = new SaveFileDialog();
					saveFileDialog.InitialDirectory = Environment.CurrentDirectory;
					saveFileDialog.Filter = "Notes *.notes|*.notes|All files *.*|*.*|Txt files *.txt|*.txt";
					if (saveFileDialog.ShowDialog() == DialogResult.OK)
					{
						FileStream fileStream = new FileStream(saveFileDialog.FileName, FileMode.Create, FileAccess.Write);
						BinaryFormatter binaryFormatter = new BinaryFormatter();
						binaryFormatter.Serialize(fileStream, notes);
						binaryFormatter.Serialize(fileStream, lstBoxAllNotes.Font);
						binaryFormatter.Serialize(fileStream, lstBoxAllNotes.ForeColor);
						binaryFormatter.Serialize(fileStream, lstBoxAllNotes.BackColor);
						foreach (var item in open_windows)
						{
							binaryFormatter.Serialize(fileStream, item.textBox1.BackColor);
							binaryFormatter.Serialize(fileStream, item.textBox1.Font);
							binaryFormatter.Serialize(fileStream, item.textBox1.ForeColor);
							binaryFormatter.Serialize(fileStream, item.txbName.BackColor);
							binaryFormatter.Serialize(fileStream, item.txbName.Font);
							binaryFormatter.Serialize(fileStream, item.txbName.ForeColor);
						}
						fileStream.Close();
						MessageBox.Show("Успешно сохранили", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
			
					}
		
				}  
		
			} 		
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace);
		
			}
		}

		private void loadToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (notes.Count > 0)
				{
					if (MessageBox.Show("Сохранить текущие заметки?", "", MessageBoxButtons.OKCancel) == DialogResult.OK)
					{
						saveToolStripMenuItem_Click(null, null);
					}
				}
				OpenFileDialog openFileDialog = new OpenFileDialog();
				openFileDialog.InitialDirectory = Environment.CurrentDirectory;
				openFileDialog.Filter = "Notes *.notes|*.notes|All files *.*|*.*|Txt files *.txt|*.txt";
				if (openFileDialog.ShowDialog() == DialogResult.OK)
				{

					if (lstBoxAllNotes.Items.Count > 0)
					{
						notes.Clear();
						lstBoxAllNotes.Items.Clear();
						open_windows.Clear();
					}
					FileStream fileStream = new FileStream(openFileDialog.FileName, FileMode.Open, FileAccess.Read);
					BinaryFormatter binaryFormatter = new BinaryFormatter();
					notes = (List<Notes>)binaryFormatter.Deserialize(fileStream);
					lstBoxAllNotes.Font = (Font)binaryFormatter.Deserialize(fileStream);
					lstBoxAllNotes.ForeColor = (Color)binaryFormatter.Deserialize(fileStream);
					lstBoxAllNotes.BackColor = (Color)binaryFormatter.Deserialize(fileStream);
					for (int i = 0; i < notes.Count; i++)
					{
						NotesForm notesForm = new NotesForm(notes[i]);
						notesForm.textBox1.BackColor = (Color)binaryFormatter.Deserialize(fileStream);
						notesForm.textBox1.Font = (Font)binaryFormatter.Deserialize(fileStream);
						notesForm.textBox1.ForeColor = (Color)binaryFormatter.Deserialize(fileStream);
						notesForm.txbName.BackColor = (Color)binaryFormatter.Deserialize(fileStream);
						notesForm.txbName.Font = (Font)binaryFormatter.Deserialize(fileStream);
						notesForm.txbName.ForeColor = (Color)binaryFormatter.Deserialize(fileStream);
						open_windows.Add(notesForm);
					}
					fileStream.Close();
					foreach (Notes item in notes)
					{
						lstBoxAllNotes.Items.Add(item);
					}
					MessageBox.Show("Успешно", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				else MessageBox.Show("Сохраненных заметок нет!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace);
			}
		}






		private void findToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (findNotes.ShowDialog() == DialogResult.OK)
				{
					if (lstBoxAllNotes.Items.Count > 0) lstBoxAllNotes.Items.Clear();
					if (searh_request.Count > 0) searh_request.Clear();
					searching = true;
					List<int> tmp = new List<int>();
					for (int i = 0; i < notes.Count; i++)
					{
						switch (findNotes.Tag.ToString())
						{
							case "1":
								if (notes[i].Text == findNotes.txbText.Text)
								{
									tmp.Add(i);
								}
								break;
							case "2":
								if (notes[i].Text == findNotes.txbname.Text)
								{
									tmp.Add(i);
								}
								break;
						}
					}
					if (findNotes.chkDate.Checked)
					{
						DateTime d = new DateTime((int)findNotes.numYear.Value, (int)findNotes.numMonth.Value, (int)findNotes.numDate.Value);
						if (d == null) return;
						for (int i = 0; i < tmp.Count; i++)
						{
							if (notes[tmp[i]].DateTime.Date == d.Date && notes[tmp[i]].DateTime.Month == d.Month && notes[tmp[i]].DateTime.Year == d.Year)
							{
								searh_request.Add(tmp[i]);
							}
						}
					}
					else
						searh_request.AddRange(tmp);

					//обновляю список итемов					
					foreach (int item in searh_request)
					{
						lstBoxAllNotes.Items.Add(notes[item]);
					}
					MessageBox.Show("Успешно", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);

				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace);
			}
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			loadToolStripMenuItem_Click(null, null);
		}

		private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
		{
			searching = false;
			if (lstBoxAllNotes.Items.Count > 0) lstBoxAllNotes.Items.Clear();
			foreach (Notes item in notes)
			{
				lstBoxAllNotes.Items.Add(item);
			}

		}

		private void CreateNote_Click(object sender, EventArgs e)
		{
			addToolStripMenuItem_Click(null, null);
		}

		private void выходToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void развернутьToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.WindowState == FormWindowState.Minimized)
			{
				this.WindowState = FormWindowState.Normal;
				this.ShowInTaskbar = true;
				развернутьToolStripMenuItem.Enabled = false;
			}
		}

		private void Form1_SizeChanged(object sender, EventArgs e)
		{
			if (this.WindowState == FormWindowState.Minimized)
			{
				развернутьToolStripMenuItem.Enabled = true;
				this.ShowInTaskbar = false;
			}
		}



		private void notifyIcon1_DoubleClick(object sender, EventArgs e)
		{
			развернутьToolStripMenuItem_Click(null, null);
		}

		private void CloseActiveStick_Click(object sender, EventArgs e)
		{
			try
			{
				if (notes.Count > 0 && lstBoxAllNotes.SelectedIndex != ListBox.NoMatches)
				{
					Notes a = notes[lstBoxAllNotes.SelectedIndex];
					if (a.Visible)
					{
						a.Visible = false;
						NotesForm n = open_windows[lstBoxAllNotes.SelectedIndex];
						n.Close();
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace);
			}
		}

		private void cntxMainWindow_Opening(object sender, CancelEventArgs e)
		{
			if (notes.Count > 0 && lstBoxAllNotes.SelectedIndex != ListBox.NoMatches)
			{
				CloseAllOpenSticks.Enabled = true;
				Notes a = notes[lstBoxAllNotes.SelectedIndex];
				if (a.Visible)
				{
					CloseActiveStick.Enabled = true;
				}
				else
					CloseActiveStick.Enabled = false;
			}
			else
			{
				CloseActiveStick.Enabled = false;
				CloseAllOpenSticks.Enabled = false;
			}
		}

		private void CloseAllOpenSticks_Click(object sender, EventArgs e)
		{
			try
			{
				if (notes.Count > 0)
				{
					for (int i = 0; i < notes.Count; i++)
					{
						if (notes[i].Visible)
						{
							notes[i].Visible = false;
							NotesForm n = open_windows[i];
							n.Close();
						}
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace);
			}
		}

		private void Form1_Load_1(object sender, EventArgs e)
		{
			if (File.Exists(Environment.CurrentDirectory + @"\mys.notes"))
			{
				FileStream fileStream = new FileStream(Environment.CurrentDirectory + @"\mys.notes", FileMode.Open, FileAccess.Read);
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				notes = (List<Notes>)binaryFormatter.Deserialize(fileStream);
				lstBoxAllNotes.Font = (Font)binaryFormatter.Deserialize(fileStream);
				lstBoxAllNotes.ForeColor = (Color)binaryFormatter.Deserialize(fileStream);
				lstBoxAllNotes.BackColor = (Color)binaryFormatter.Deserialize(fileStream);
				for (int i = 0; i < notes.Count; i++)
				{
					NotesForm notesForm = new NotesForm(notes[i]);
					notesForm.textBox1.BackColor = (Color)binaryFormatter.Deserialize(fileStream);
					notesForm.textBox1.Font = (Font)binaryFormatter.Deserialize(fileStream);
					notesForm.textBox1.ForeColor = (Color)binaryFormatter.Deserialize(fileStream);
					notesForm.txbName.BackColor = (Color)binaryFormatter.Deserialize(fileStream);
					notesForm.txbName.Font = (Font)binaryFormatter.Deserialize(fileStream);
					notesForm.txbName.ForeColor = (Color)binaryFormatter.Deserialize(fileStream);
					open_windows.Add(notesForm);
				}
				fileStream.Close();
				foreach (Notes item in notes)
				{
					lstBoxAllNotes.Items.Add(item);
				}
			}
		}

		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			FileStream fileStream = new FileStream(Environment.CurrentDirectory + @"\my(autosave).notes", FileMode.Create, FileAccess.Write);
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			binaryFormatter.Serialize(fileStream, notes);
			binaryFormatter.Serialize(fileStream, lstBoxAllNotes.Font);
			binaryFormatter.Serialize(fileStream, lstBoxAllNotes.ForeColor);
			binaryFormatter.Serialize(fileStream, lstBoxAllNotes.BackColor);
			foreach (var item in open_windows)
			{
				binaryFormatter.Serialize(fileStream, item.textBox1.BackColor);
				binaryFormatter.Serialize(fileStream, item.textBox1.Font);
				binaryFormatter.Serialize(fileStream, item.textBox1.ForeColor);
				binaryFormatter.Serialize(fileStream, item.txbName.BackColor);
				binaryFormatter.Serialize(fileStream, item.txbName.Font);
				binaryFormatter.Serialize(fileStream, item.txbName.ForeColor);
			}
			fileStream.Close();
		}
	}
}
